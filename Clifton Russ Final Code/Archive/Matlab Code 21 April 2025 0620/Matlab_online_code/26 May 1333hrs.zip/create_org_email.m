function [checked_email,report_email] = create_org_email(vuln_incident_total,a_size, actions_size)
%checked_email = cell(a_size, days);
%report_email = cell(a_size,days);
%agent_email_total = cell(1,days);

%{
for m = 1: a_size
    for n = 1: days
        [agent_email,~] = agent_interaction_create_email();
        %agent_email_total{1,j} = agent_email;
        [checked_email{m,n}, report_email{m,n}] = calculate_email_report(vuln_incident_total{m,n},agent_email, actions_size);
        %[checked_email{i,j}, report_email{i,j}] = calculate_email_report(vuln_incident_total(i,j),agent_email, actions_size);
        %[checked_email{i,j}, report_email{i,j}] = calculate_email_report(vuln_incident_total,agent_email, actions_size);
    end
end
%}


%A = rand(1,4);
x = 0;
for m = 1: a_size
    for n = 1: days
        [agent_email,~] = agent_interaction_create_email();
        %agent_email_total{1,j} = agent_email;
        [checked_email, report_email] = calculate_email_report(vuln_incident_total{m,x+1},agent_email, actions_size);
        x = x+1; % for some reason there is an error using a forloop variable
        %[checked_email{i,j}, report_email{i,j}] = calculate_email_report(vuln_incident_total(i,j),agent_email, actions_size);
        %[checked_email{i,j}, report_email{i,j}] = calculate_email_report(vuln_incident_total,agent_email, actions_size);
    end
end
%}
end