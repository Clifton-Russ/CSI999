function [training_labels] = create_training_label(array_breach,days,state_index)

%% 
% This merges all the breaches into one matrix for each day to be used as
% labels
breach_sum = cell(1,days);
for i = 1: days
    breach_sum{1,i} = cell2mat(array_breach(:,i));
end
%% Extract labels for state 1:
% This takes the breach results for the given state 
 breach_state = cell(1,days);
for i = 1: days
    %for j = 1: a_size
        temp = breach_sum{1,i}(:,state_index);
        breach_state{1,i} = temp;
    %end
end

%% Combines labels for state 1
% This combines the labels for the given state 
training_labels = cell2mat(breach_state(:));


end  