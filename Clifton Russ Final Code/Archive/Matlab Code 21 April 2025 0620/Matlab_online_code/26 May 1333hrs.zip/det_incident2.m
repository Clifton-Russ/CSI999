function [c_incidents] = det_incident2(agent,e_thresholds)

%% Determine the size of the thresholds for each control
e_size = size(e_thresholds,2);
%%
c_incidents = zeros(1,e_size);
%% Calculates the a_incident score.
% For each agent, their threat score (as defined within People) are
% compared to sets of RMF control threshold scores relevant to the threat
% score. For example, phishing threat scores are related to controls where
% a noncompliance in an RMF control would yield a vulnerability to phishing

for j = 1: e_size
    if agent > e_thresholds(1,j)
        c_incidents(1,j) = 1;
    end
end
    

end