function [control_count, control_cell] = determine_control_count(e_thresholds,control_size)
%% Combine control attributes

%{
e thresholds is a matrix where each column represents a specific
vulnerability and each row represents the control families associated with
each vulnerability. For example, rows 1,2 and 3 might represent AC, AT and
AU. While columns 1,2 and 3 might represent piggybacking, phishing and
viruses. Each entry represents the associated controls that are applicable
to that vulnerability. For example, the AC controls that are applicable to
piggybacking aren't the same for the AC controls that are applicable for
phishing

%}

% Calculating the controls for the first vulnerability 


%{

e1_1 = toArray(e_thresholds(1,1),control_size(1,1));    
e1_2 = toArray(e_thresholds(2,1),control_size(2,1));
e1_3 = toArray(e_thresholds(3,1),control_size(3,1));
e1_4 = toArray(e_thresholds(4,1),control_size(4,1));
e1_5 = toArray(e_thresholds(5,1),control_size(5,1));
e1_6 = toArray(e_thresholds(6,1),control_size(6,1));
control_count{1,1} = [e1_1 e1_2 e1_3 e1_4 e1_5 e1_6];

control_cell{1,1} = e1_1;
control_cell{2,1} = e1_2;
control_cell{3,1} = e1_3;
control_cell{4,1} = e1_4;
control_cell{5,1} = e1_5;
control_cell{6,1} = e1_6;


% Calculating the controls for the second vulnerability
e2_1 = toArray(e_thresholds(1,2),control_size(1,2));    
e2_2 = toArray(e_thresholds(2,2),control_size(2,2));
e2_3 = toArray(e_thresholds(3,2),control_size(3,2));
e2_4 = toArray(e_thresholds(4,2),control_size(4,2));
e2_5 = toArray(e_thresholds(5,2),control_size(5,2));
e2_6 = toArray(e_thresholds(6,2),control_size(6,2));
control_count{2,1} = [e2_1 e2_2 e2_3 e2_4 e2_5 e2_6];

control_cell{1,2} = e2_1;
control_cell{2,2} = e2_2;
control_cell{3,2} = e2_3;
control_cell{4,2} = e2_4;
control_cell{5,2} = e2_5;
control_cell{6,2} = e2_6;

% Calculating the controls for the third vulnerability
e3_1 = toArray(e_thresholds(1,3),control_size(1,3));    
e3_2 = toArray(e_thresholds(2,3),control_size(2,3));
e3_3 = toArray(e_thresholds(3,3),control_size(3,3));
e3_4 = toArray(e_thresholds(4,3),control_size(4,3));
e3_5 = toArray(e_thresholds(5,3),control_size(5,3));
e3_6 = toArray(e_thresholds(6,3),control_size(6,3));
control_count{3,1} = [e3_1 e3_2 e3_3 e3_4 e3_5 e3_6];

control_cell{1,3} = e3_1;
control_cell{2,3} = e3_2;
control_cell{3,3} = e3_3;
control_cell{4,3} = e3_4;
control_cell{5,3} = e3_5;
control_cell{6,3} = e3_6;

% Calculating the controls for the fourth vulnerability
e4_1 = toArray(e_thresholds(1,4),control_size(1,4));    
e4_2 = toArray(e_thresholds(2,4),control_size(2,4));
e4_3 = toArray(e_thresholds(3,4),control_size(3,4));
e4_4 = toArray(e_thresholds(4,4),control_size(4,4));
e4_5 = toArray(e_thresholds(5,4),control_size(5,4));
e4_6 = toArray(e_thresholds(6,4),control_size(6,4));
control_count{4,1} = [e4_1 e4_2 e4_3 e4_4 e4_5 e4_6];

control_cell{1,4} = e4_1;
control_cell{2,4} = e4_2;
control_cell{3,4} = e4_3;
control_cell{4,4} = e4_4;
control_cell{5,4} = e4_5;
control_cell{6,4} = e4_6;

% Calculating the controls for the five vulnerability
e5_1 = toArray(e_thresholds(1,5),control_size(1,5));    
e5_2 = toArray(e_thresholds(2,5),control_size(2,5));
e5_3 = toArray(e_thresholds(3,5),control_size(3,5));
e5_4 = toArray(e_thresholds(4,5),control_size(4,5));
e5_5 = toArray(e_thresholds(5,5),control_size(5,5));
e5_6 = toArray(e_thresholds(6,5),control_size(6,5));
control_count{5,1} = [e5_1 e5_2 e5_3 e5_4 e5_5 e5_6];

control_cell{1,5} = e5_1;
control_cell{2,5} = e5_2;
control_cell{3,5} = e5_3;
control_cell{4,5} = e5_4;
control_cell{5,5} = e5_5;
control_cell{6,5} = e5_6;

% Calculating the controls for the six vulnerability
e6_1 = toArray(e_thresholds(1,6),control_size(1,6));    
e6_2 = toArray(e_thresholds(2,6),control_size(2,6));
e6_3 = toArray(e_thresholds(3,6),control_size(3,6));
e6_4 = toArray(e_thresholds(4,6),control_size(4,6));
e6_5 = toArray(e_thresholds(5,6),control_size(5,6));
e6_6 = toArray(e_thresholds(6,6),control_size(6,6));
control_count{6,1} = [e6_1 e6_2 e6_3 e6_4 e6_5 e6_6];

control_cell{1,6} = e6_1;
control_cell{2,6} = e6_2;
control_cell{3,6} = e6_3;
control_cell{4,6} = e6_4;
control_cell{5,6} = e6_5;
control_cell{6,6} = e6_6;

%e_threshold_1 = toArray(e_thresholds(1,:),control_size(1,1));
%e_threshold_2 = toArray(e_thresholds(2,:),control_size(2,1));
%control_count{1,1} = [e_threshold_1 e_threshold_2];
%{
e_threshold_4 = toArray(e_thresholds(4,:),control_size(4,1));
e_threshold_3 = toArray(e_thresholds(3,:),control_size(3,1));
control_count{1,2} = [e_threshold_4 e_threshold_3];

e_threshold_3 = toArray(e_thresholds(3,:),control_size(3,1));
e_threshold_1 = toArray(e_thresholds(1,:),control_size(1,1));
control_count{1,3} = [e_threshold_3 e_threshold_1];

e_threshold_6 = toArray(e_thresholds(6,:),control_size(6,1));
e_threshold_5 = toArray(e_thresholds(5,:),control_size(5,1));
control_count{1,4} = [e_threshold_6 e_threshold_5];

e_threshold_3 = toArray(e_thresholds(3,:),control_size(3,1));
e_threshold_5 = toArray(e_thresholds(5,:),control_size(5,1));
control_count{1,5} = [e_threshold_3 e_threshold_5];


%}
%}
end