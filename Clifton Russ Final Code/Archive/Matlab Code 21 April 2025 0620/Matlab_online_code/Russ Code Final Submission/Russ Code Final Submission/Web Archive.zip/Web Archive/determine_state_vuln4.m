function [c_family_incident] = determine_state_vuln4(n,agent_average, mc_baseline,actions_size, control_count,vuln_ctrl_size)
%% This determines which e_threshold data to use based on the current state

mc_size = size(mc_baseline,1);
c_family_incident = cell(mc_size,actions_size);
c_family_incident(:) = {0}; 

%% Taking the mean of agents' compliance

agent = agent_average;

%% Combine control attributes

%for loop determines if there is an incident        
for i = 1:mc_size
    if mc_baseline(i,1) == 1 % This includes controls 1 &2
        
        
        %This preallocates values to ensure that zero values are preserved
        temp1 = zeros(1,vuln_ctrl_size(1,1));
        temp2 = zeros(1,vuln_ctrl_size(1,2));
        
        % This determines the incidents for the controls in respect to the
        % first threat and then converts it into a matrix.
        temp1 = temp1 + cell2mat(determine_incident(agent,control_count(1,1)));
        
        % This determines the incidents for the controls in respect to the
        % second threat and then converts it into a matrix.
        temp2 = temp2 + cell2mat(determine_incident(agent,control_count(1,2)));
        
        %Since this state involves vulnerabilities in respect to both
        %threats 1 and 2, both sets of controls are combined to represent
        %the total amount of vulnerabilities.
       
        temp3 = [temp1 temp2];
       % c_family_incident{i,1} = zeros(1,control_size(1,1)+control_size(1,2));
        c_family_incident{i,1} = temp3;
      
    elseif mc_baseline(i,1) == 2 % This includes controls 3 & 4
       
% This determines the incidents for the controls in respect to the
        % third threat and then converts it into a matrix.
        temp1 = cell2mat(determine_incident(agent,control_count(1,3)));
        
        % This determines the incidents for the controls in respect to the
        % fourth threat and then converts it into a matrix.
        temp2 = cell2mat(determine_incident(agent,control_count(1,4)));
        
        %Since this state involves vulnerabilities in respect to both
        %threats 3 and 4, both sets of controls are combined to represent
        %the total amount of vulnerabilities.
        temp3 = [temp1 temp2];
        %c_family_incident{i,2} = zeros(1,control_size(1,3)+control_size(1,4));
        c_family_incident{i,2} = c_family_incident{i,2}(1,1) + temp3;

    elseif mc_baseline(i,1) == 3 % This includes controls 1 & 3
       
        
        % This determines the incidents for the controls in respect to the
        % first threat and then converts it into a matrix.
        temp1 = cell2mat(determine_incident(agent,control_count(1,1)));
        
        % This determines the incidents for the controls in respect to the
        % third threat and then converts it into a matrix.
        temp2 = cell2mat(determine_incident(agent,control_count(1,3)));
        
        %Since this state involves vulnerabilities in respect to both
        %threats 1 and 3, both sets of controls are combined to represent
        %the total amount of vulnerabilities.
        temp3 = [temp1 temp2];
        
        %c_family_incident{i,3} = zeros(1,control_size(1,1)+control_size(1,3));
        c_family_incident{i,3} = c_family_incident{i,3}(1,1) + temp3;

     
    elseif mc_baseline(i,1) == 4 % This includes controls 5 & 6 
       
        % This determines the incidents for the controls in respect to the
        % fifth threat and then converts it into a matrix.
        temp1 = cell2mat(determine_incident(agent,control_count(1,5)));
        
        % This determines the incidents for the controls in respect to the
        % sixth threat and then converts it into a matrix.
        temp2 = cell2mat(determine_incident(agent,control_count(1,6)));
        
        %Since this state involves vulnerabilities in respect to both
        %threats 5 and 6, both sets of controls are combined to represent
        %the total amount of vulnerabilities.
        temp3 = [temp1 temp2];
        
        %c_family_incident{i,4} = zeros(1,control_size(1,5)+control_size(1,6));
        c_family_incident{i,4} = c_family_incident{i,4}(1,1) + temp3;

       

    elseif mc_baseline(i,1) == 5 % This includes controls 3 & 5
        
       
        % This determines the incidents for the controls in respect to the
        % third threat and then converts it into a matrix.
        temp1 = cell2mat(determine_incident(agent,control_count(1,3)));
        
        % This determines the incidents for the controls in respect to the
        % fifth threat and then converts it into a matrix.
        temp2 = cell2mat(determine_incident(agent,control_count(1,5)));
        
        %Since this state involves vulnerabilities in respect to both
        %threats 3 and 5, both sets of controls are combined to represent
        %the total amount of vulnerabilities.
        temp3 = [temp1 temp2];
        
        %c_family_incident{i,5} = zeros(1,control_size(1,3)+control_size(1,5));
        c_family_incident{i,5} = c_family_incident{i,5}(1,1) + temp3;

    
    end
      
end

end