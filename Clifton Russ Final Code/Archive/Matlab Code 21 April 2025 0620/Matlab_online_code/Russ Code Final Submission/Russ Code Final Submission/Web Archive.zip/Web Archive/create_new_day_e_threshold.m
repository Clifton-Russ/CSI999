function [control_vuln] = create_new_day_e_threshold(e_thresholds,num_control, vuln_size)

% This recreates the entire e thresholds score with a 5% variance for each
% day.
control_vuln = zeros(num_control,vuln_size);
for P = 1: num_control
    for Q = 1: vuln_size 
        min = e_thresholds{P,1}(1,Q)-(.05*e_thresholds{P,1}(1,Q));
        max = e_thresholds{P,1}(1,Q)+(.05*e_thresholds{P,1}(1,Q));
        r = randi([5 25],1, 1);
        control_vuln{P,Q}= min + (max-min)*rand(1,control_size(P,Q));
    end
end
end