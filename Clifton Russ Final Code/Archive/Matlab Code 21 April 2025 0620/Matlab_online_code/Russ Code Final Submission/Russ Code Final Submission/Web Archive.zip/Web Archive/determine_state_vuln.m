function [mc_incident, control_incident] = determine_state_vuln(n,people, mc_baseline, e_thresholds,num_control,vuln_control_count)
%% This determines which e_threshold data to use based on the current state

mc_size = size(mc_baseline,1);
mc_incident = cell(mc_size,1);
mc_incident(:) = {0};   

%% Determine the control size for each vulnerability

e_size = size(e_thresholds,2);
control_size = zeros(num_control,e_size);
for i = 1 : num_control %e_size
    for j = 1:e_size %num_control
        control_size(i,j) = size(e_thresholds{i,j},2);
    end
end

%% Define variables to count the number of incidents for each control


control_incident = cell(num_control,1);
%control_incident(:) = {0};
%control_incident = repmat({zeros(1,1)},1,6);

for i = 1: num_control
     control_incident{i,1} = zeros(1, control_size(i,1));
 end

%% Combine control attributes

%[control_count] = determine_control_count(e_thresholds,control_size);

%for loop determines if there is an incident        
for i = 1:mc_size
    if mc_baseline(i,1) == 1 % This includes controls 1 &2
        agent = people{n,3}(1,1);
        mc_incident{i,1} = determine_incident(agent,vuln_control_count(1,1));
       
        % This is adding the information for the first inc/vuln
        e_1 = toArray(e_thresholds(1,1),control_size(1,1));
        temp = det_incident2(agent,e_1);
        control_incident{1,1} = control_incident{1,1}(1,1) + temp;
        
      
        % This is adding the information for the second inc/vuln
        e_2 = toArray(e_thresholds(2,1),control_size(2,1));
        temp = det_incident2(agent,e_2);
        control_incident{2,1} = control_incident{2,1}(1,1) + temp;
        
       
    elseif mc_baseline(i,1) == 2 % This includes controls 3 & 4
        agent = people{n,3}(1,2);
        
        mc_incident{i,1} = determine_incident(agent,vuln_control_count(1,2));
        
       % This is adding the information for the third inc/vuln
        e_3 = toArray(e_thresholds(3,1),control_size(3,1));
        temp = det_incident2(agent,e_3);
        control_incident{3,1} = control_incident{3,1}(1,1) + temp;
        
      
        % This is adding the information for the fourth inc/vuln
        e_4 = toArray(e_thresholds(4,1),control_size(4,1));
        temp = det_incident2(agent,e_4);
        control_incident{4,1} = control_incident{4,1}(1,1) + temp;

    elseif mc_baseline(i,1) == 3 % This includes controls 1 & 3
        agent = people{n,3}(1,3);
        mc_incident{i,1} = determine_incident(agent,vuln_control_count(1,3));

     % This is adding the information for the first inc/vuln
        e_1 = toArray(e_thresholds(1,1),control_size(1,1));
        temp = det_incident2(agent,e_1);
        control_incident{1,1} = control_incident{1,1}(1,1) + temp;
        
     % This is adding the information for the third inc/vuln
        e_3 = toArray(e_thresholds(3,1),control_size(3,1));
        temp = det_incident2(agent,e_3);
        control_incident{3,1} = control_incident{3,1}(1,1) + temp;

    elseif mc_baseline(i,1) == 4 % This includes controls 5 & 6 
        agent = people{n,3}(1,4); 
        mc_incident{i,1} = determine_incident(agent,vuln_control_count(1,4));

         % This is adding the information for the third inc/vuln
        e_5 = toArray(e_thresholds(5,1),control_size(5,1));
        temp = det_incident2(agent,e_5);
        control_incident{5,1} = control_incident{5,1}(1,1) + temp;

         % This is adding the information for the third inc/vuln
        e_6 = toArray(e_thresholds(6,1),control_size(6,1));
        temp = det_incident2(agent,e_6);
        control_incident{6,1} = control_incident{6,1}(1,1) + temp;


    elseif mc_baseline(i,1) == 5 % This includes controls 3 & 5
        agent = people{n,3}(1,5);
        mc_incident{i,1} = determine_incident(agent,vuln_control_count(1,5));

         % This is adding the information for the third inc/vuln
        e_3 = toArray(e_thresholds(3,1),control_size(3,1));
        temp = det_incident2(agent,e_3);
        control_incident{3,1} = control_incident{3,1}(1,1) + temp;

        % This is adding the information for the third inc/vuln
        e_5 = toArray(e_thresholds(5,1),control_size(5,1));
        temp = det_incident2(agent,e_5);
        control_incident{5,1} = control_incident{5,1}(1,1) + temp;
    end

end

end