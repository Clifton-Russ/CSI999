function [variable] = create_e_variable(e_thresholds, control_size, num_control,e_size)
% This function extracts the e_thresholds from the cell array, converts
% them to a normal array and then assign them to a variable to be
% grouped/used in the future.

% Each row represents an entire control family. Each column represents a
% subset of the control family. The control family is broken up into
% subsets as some controls are used


for i = 1:num_control
    for j = 1:e_size
        my_field = strcat('e',num2str(i),'_',num2str(j));
        variable.(my_field) = toArray(e_thresholds(1,j),control_size(1,j));  
    end
end


end