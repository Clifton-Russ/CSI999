function [vuln_matrix_sorted] = sort_vuln_matrix(vuln_combo,vuln_matrix,actions_size)
% This method sorts the vulnerability to matrix to ensure that each column
% entry is aligned with the corresponding vulnerability. For example,
% column 1 is aligned with vulnerability 1.

vuln_matrix_sorted = cell(1,actions_size);
%counter = size(cell2mat(vuln_combo(1,1)),2);
counter = size(cell2mat(vuln_combo),2);
for i = 1:counter
    index = vuln_combo{1,1}(1,i);
    vuln_matrix_sorted(1,index) = vuln_matrix(1,i);
    %vuln_matrix_sorted{1,1}(1,index) = vuln_matrix{1,1}(1,i);
end
end