%% Thoughts
% Use unsupervised learning to see if the outcome is the same or able to
% predict new incidents
% Compare different types of supervised learning techniques
% 14 days for input, for 1 year, 3 years, 6 years and 10 years. Change each
% 14 days by +/- 10%.
% e_thresholds times the number of times the occurrence in the mc.
% Count the number of times each step.

% For each row of controls (represented by control by each day), [input],
% the output is a single digit or string for each any breach. If there is
% more than one, either the threat with the most breaches or a combination.

% calculate a way to determine the average of incidents per state. If the
% average is above 50%, then it's considered an incident. This will be the
% input for that day for that state.

% Determine state vuln and determine incident
% vuln control size determines the amount controls for each vulnerability.
% For each step, the total number of controls need to be calculated. For
% example, step 1 involves vuln1 and vuln 2, so add vuln size 1 and vuln
% size 2. Once that is added, then for each person, that number needs to be
% multiplied for the number of times each step occurs. For example, if
% person 1 was in step 1 10 times, then the number would be 10 times (vuln
% size 1 + vuln size 2). Once that number is calculated (vuln_total), that
% will act as the denominator. Dividing the part / whole will give a
% percentage of incidents. This number can then be used to either determine
% the output layer or label.

% output layer, each vulnerability (1 or 0) and NA (1 or 0). List all
% controls as the input. This trains against all vulnerabilities at once.

% control size = number of each controls for each vulnerability
% vuln_control count: sum of control size columns. The total amount of
% controls for each vulnerability
% vuln incident total = total sum of incidents per person, per day, per
% step.
% sort through mc-baseline to determine the amount steps per day.


% Currently, the vuln1 input and attribute information are random and need to be separated from
% specifically chosen controls.

% Need to focus on simulating agent movement and less on predictions.


%%
%isempty(cell2mat(vuln1_scores{1,1}(3,1)))
%likelihood = round(vuln1_scores(1,i)*.21);
% Converts the incident matrix to an array and sum all incidents
        %temp = sum(cell2mat(vuln1_scores{i,j}));
        % likelihood for agent clicking the link.
        %likelihood = round(temp *.21);
       % likelihood = .51;
%%
%input label includes the vuln1_scores for the day and the +1 is the label
%to determine if it were a breach.

%{
vuln_breach2 = cell(a_size,days);
temp = cell(a_size,days);

% This is only done for setting up for prediction modeling.
for i = 1: a_size
    for j = 1:days  
        
        [vuln_breach2{i,j}, temp{i,j}] = determine_breach3(vuln_1{i,j}, incident_threshold, steps(i,j),attribute_size,likelihood);
    end
    %input_label = cell2mat(vuln_breach{1,1}(1,1))';
end
%}
%%
% links, forward email. Then calculate per person, per day, per activity
% Fix determine breach. incident size is incorrect


% calculate instances where phishing attacks fail
% Determine the amount of people in survey/percentage
% Assume that the agents receive the same attacks
% range of steps, risk (phishing)/different
% controls.
% Slide 31- Social Engineering
% Used 21% for exposure based on the number of incidents reported within a
% year.
% adjust scores for various scenarios and then check to see if percentage
% is closer to 4%
% compare what happens when reduce the number of steps

%%
%1. Select controls again determine_attribute
% Need to calculalte for each agent as opposed to one person
% 98% email 

%%
%agent_click = toArray(agent_click,click_size);
%% This saves the plot in a temporary variable. The variable needs to be saved in order to be maintained. 
%click_figure = create_plot(agent_comp,agent_click, actions_size);
%%
% For each reported email, tag the email as reported. If an email is tagged
% as reported in the future, then it is considered "null".

%%
%agent_comp = [60 65, 70, 75, 80, 85, 90, 95];


%%
%{
add_email_index = randi([1, 5],1,1);
add_email = randi([0, 1],1,add_email_index);
email_original{1,1} = agent_email_total{1,2}{1,2}(1,:);
temp = [email_original{1,1}, add_email];
%}

%% Demonstrates multiple runs
percent_60 = [  0.0327 0.0227 0.0328 0.0201; 
 0.0329 0.0222 0.0320 0.0216;
 0.0330 0.0221 0.0331 0.0227;
 0.0332 0.0221 0.0319 0.0220;
 0.0323 0.0212 0.0331 0.0235;
 0.0326 0.0229 0.0330 0.0219;
 0.0329 0.0231 0.0327 0.0213;
 0.0323 0.0220 0.0327 0.0218;
 0.0332 0.0222 0.0329 0.0220;
 0.0325 0.0223 0.0324 0.0248];

percent_65 = [0.0291 0.0203 0.0293 0.0116;
 0.0292 0.0195 0.0288 0.0113;
 0.0294 0.0195 0.0291 0.0136;
 0.0293 0.0209 0.0298 0.0114;
 0.0286 0.0200 0.0297 0.0107;
 0.0291 0.0197 0.0293 0.0119;
 0.0292 0.0200 0.0298 0.0117;
 0.0294 0.0199 0.0294 0.0114;
 0.0288 0.0198 0.0295 0.0112;
 0.0286 0.0197 0.0293 0.0112];

percent_70 = [ 0.0258 0.0177 0.0245 0.0046;
 0.0260 0.0185 0.0247 0.0050;
 0.0257 0.0169 0.0237 0.0048;
 0.0263 0.0170 0.0247 0.0051;
 0.0265 0.0165 0.0243 0.0050;
 0.0263 0.0169 0.0246 0.0045;
 0.0262 0.0175 0.0252 0.0047;
 0.0261 0.0173 0.0246 0.0049;
 0.0259 0.0173 0.0249 0.0053;
 0.0263 0.0170 0.0249 0.0055];

percent_75 = [ 0.0237 0.0137 0.0177 0.0016;
 0.0236 0.0140 0.0181 0.0017;
 0.0231 0.0141 0.0187 0.0018;
 0.0226 0.0142 0.0188 0.0014;
 0.0232 0.0138 0.0186 0.0022;
 0.0228 0.0133 0.0179 0.0015;
 0.0242 0.0139 0.0176 0.0011;
 0.0237 0.0145 0.0185 0.0020;
 0.0228 0.0133 0.0178 0.0026;
 0.0239 0.0133 0.0172 0.0016];

percent_80 = [ 0.0150 0.0128 0.0127 0;
 0.0152 0.0128 0.0135 0;
 0.0152 0.0129 0.0130 0;
 0.0145 0.0117 0.0134 0;
 0.0142 0.0123 0.0131 0;
 0.0143 0.0130 0.0138 0;
 0.0138 0.0129 0.0128 0;
 0.0143 0.0126 0.0129 0;
 0.0139 0.0126 0.0133 0;
 0.0144 0.0120 0.0136 0];

percent_85 = [0.0092 0.0124 0.0080 0;
0.0089 0.0128 0.0073 0;
0.0090 0.0127 0.0075 0;
0.0089 0.0129 0.0082 0;
0.0091 0.0127 0.0083 0;
0.0098 0.0119 0.0077 0;
0.0102 0.0119 0.0074 0;
0.0090 0.0124 0.0078 0;
0.0093 0.0137 0.0083 0;
0.0096 0.0130 0.0076 0];

percent_90 = [0.0045 0.0032 0.0067 0;
0.0047 0.0026 0.0066 0;
0.0045 0.0031 0.0065 0;
0.0049 0.0033 0.0066 0;
0.0048 0.0027 0.0063 0;
0.0049 0.0025 0.0064 0;
0.0046 0.0028 0.0068 0;
0.0049 0.0027 0.0068 0;
0.0045 0.0030 0.0063 0;
0.0047 0.0028 0.0066 0];

percent_95 = [0.0002 0.0024 0.0035 0;
0.0002 0.0026 0.0034 0;
0.0004 0.0028 0.0032 0;
0.0002 0.0026 0.0033 0;
0.0006 0.0025 0.0032 0;
0.0005 0.0026 0.0034 0;
0.0003 0.0025 0.0032 0;
0.0006 0.0025 0.0030 0;
0.0003 0.0023 0.0032 0;
0.0007 0.0023 0.0034 0];
%% Create the separate instances (multiples of 10) for Messenging

agent_click_activity_1 = zeros(10,8);
agent_click_activity_1(:,1) = percent_60(:,1);
agent_click_activity_1(:,2) = percent_65(:,1);
agent_click_activity_1(:,3) = percent_70(:,1);
agent_click_activity_1(:,4) = percent_75(:,1);
agent_click_activity_1(:,5) = percent_80(:,1);
agent_click_activity_1(:,6) = percent_85(:,1);
agent_click_activity_1(:,7) = percent_90(:,1);
agent_click_activity_1(:,8) = percent_95(:,1);

agent_click_activity_1 = agent_click_activity_1.*100;

%% Scatterplot of percentages (Checking Email)
agent_comp = [60 65, 70, 75, 80, 85, 90, 95];

for i = 1: 10
    scatter(agent_comp',agent_click_activity_1(i,:));
    hold on
end
title("Agent Click Rate for Checking email")
xlabel('Agent Compliance')
ylabel('Click Rate Percentage')
set(gcf, 'Name', 'By the Agent click Rate')
%legend('Messenger')
hold off
%% Create the separate instances (multiples of 10) for Websurfing

agent_click_activity_2 = zeros(10,8);
agent_click_activity_2(:,1) = percent_60(:,2);
agent_click_activity_2(:,2) = percent_65(:,2);
agent_click_activity_2(:,3) = percent_70(:,2);
agent_click_activity_2(:,4) = percent_75(:,2);
agent_click_activity_2(:,5) = percent_80(:,2);
agent_click_activity_2(:,6) = percent_85(:,2);
agent_click_activity_2(:,7) = percent_90(:,2);
agent_click_activity_2(:,8) = percent_95(:,2);

agent_click_activity_2 = agent_click_activity_2.*100;
%% Scatterplot of percentages (Websurfing)
agent_comp = [60 65, 70, 75, 80, 85, 90, 95];

for i = 1: 10
    scatter(agent_comp',agent_click_activity_2(i,:));
    hold on
end
title("Agent Click Rate for Websurfing")
xlabel('Agent Compliance')
ylabel('Click Rate Percentage')
set(gcf, 'Name', 'By the Agent click Rate')
%legend('Messenger')
hold off


%% Create the separate instances (multiples of 10) for Mobile Phone

agent_click_activity_3 = zeros(10,8);
agent_click_activity_3(:,1) = percent_60(:,3);
agent_click_activity_3(:,2) = percent_65(:,3);
agent_click_activity_3(:,3) = percent_70(:,3);
agent_click_activity_3(:,4) = percent_75(:,3);
agent_click_activity_3(:,5) = percent_80(:,3);
agent_click_activity_3(:,6) = percent_85(:,3);
agent_click_activity_3(:,7) = percent_90(:,3);
agent_click_activity_3(:,8) = percent_95(:,3);

agent_click_activity_3 = agent_click_activity_3.*100;
%% Scatterplot of percentages (Mobile Phone)
agent_comp = [60 65, 70, 75, 80, 85, 90, 95];

for i = 1: 10
    scatter(agent_comp',agent_click_activity_3(i,:));
    hold on
end
title("Agent Click Rate for Mobile Phone")
xlabel('Agent Compliance')
ylabel('Click Rate Percentage')
set(gcf, 'Name', 'By the Agent click Rate')
%legend('Messenger')
hold off


%% Create the separate instances (multiples of 10) for Messenger

agent_click_activity_4 = zeros(10,8);
agent_click_activity_4(:,1) = percent_60(:,4);
agent_click_activity_4(:,2) = percent_65(:,4);
agent_click_activity_4(:,3) = percent_70(:,4);
agent_click_activity_4(:,4) = percent_75(:,4);
agent_click_activity_4(:,5) = percent_80(:,4);
agent_click_activity_4(:,6) = percent_85(:,4);
agent_click_activity_4(:,7) = percent_90(:,4);
agent_click_activity_4(:,8) = percent_95(:,4);

agent_click_activity_4 = agent_click_activity_4.*100;
%% Scatterplot of percentages (Messenger)
agent_comp = [60 65, 70, 75, 80, 85, 90, 95];

for i = 1: 10
    scatter(agent_comp',agent_click_activity_4(i,:));
    hold on
end
title("Agent Click Rate for Messenger")
xlabel('Agent Compliance')
ylabel('Click Rate Percentage')
set(gcf, 'Name', 'By the Agent click Rate')
%legend('Messenger')
hold off

%% For loop to determine the total of emails reported

 r_email_total = cell(1, days);
for i = 1: days
    r_email_total{1,i} = sum(cell2mat(r_email(:,i)),1);
end

%% For loop to summarize all reported emails for all days

r_email_total_by_activity = zeros(1,actions_size);
for i = 1: days
    for j = 1: actions_size
        r_email_total_by_activity(1,j) = r_email_total_by_activity(1,j) + r_email_total{1,i}(1,j);
    end
end
%% For loop to determine the total of checked emails 

 c_email_total = cell(1, days);
for i = 1: days
    c_email_total{1,i} = sum(cell2mat(c_email(:,i)),1);
end
%% For loop to summarize all checked emails for all days

c_email_total_by_activity = zeros(1,actions_size);
for i = 1: days
    for j = 1: actions_size
        c_email_total_by_activity(1,j) = c_email_total_by_activity(1,j) + c_email_total{1,i}(1,j);
    end
end
%%
r_email_percentage = r_email_total_by_activity./c_email_total_by_activity;



%% For loop to determine the total of checked emails (forwarded)

 c_email_total_new = cell(1, days);
for i = 1: days
    c_email_total_new{1,i} = sum(cell2mat(c_email(:,i)),1);
end

 c_email_total_old = cell(1, days);
for i = 1: days
    c_email_total_old{1,i} = sum(cell2mat(c_email_old(:,i)),1);
end
%% For loop to summarize all checked emails for all days (Forward)

c_email_total_by_activity_new = zeros(1,actions_size);
for i = 1: days
    for j = 1: actions_size
        c_email_total_by_activity_new(1,j) = c_email_total_by_activity_new(1,j) + c_email_total_new{1,i}(1,j);
    end
end

c_email_total_by_activity_old = zeros(1,actions_size);
for i = 1: days
    for j = 1: actions_size
        c_email_total_by_activity_old(1,j) = c_email_total_by_activity_old(1,j) + c_email_total_old{1,i}(1,j);
    end
end
%% calculate the checked email increase (Forward)
c_email_increase = (c_email_total_by_activity_new -c_email_total_by_activity_old )./c_email_total_by_activity_old;
%% This creates the variables used for the method to calculate multiple runs
a_size_total = 10;
days = 50;
%agent_compliance_average = .70;
incident_threshold = .043;
phish_report_rate = .60;

%%

agent_compliance_average = [.60, .65, .70, .75, .80, .85, .90, .95];

%incident_threshold = [.025, .035, .02, .01];
%phish_report_rate = [.7,.6,.75,.80];
agent_compliance_size = size(agent_compliance_average,2);
%team_size = 4;
observation_size = 20;

click_percent_step_mean = cell(observation_size, agent_compliance_size);
report_rate = cell (observation_size,agent_compliance_size);

%a_size_total = [100, 75, 50, 25];
%%
%[click_percent_step_mean,report_rate, vuln_incident_total] = create_suborganization(a_size_total, days, agent_compliance_average, incident_threshold, phish_report_rate);


%% This does 20 iterations for all agent compliance
for i = 1:20
    for j = 1:agent_compliance_size
        [click_percent_step_mean{i,j},report_rate{i,j}, vuln_incident_total] = ...
            create_suborganization(a_size_total, days, agent_compliance_average(1,j), incident_threshold, phish_report_rate);
    end
end

%% This converts the results into one matrix
A = toArray(click_percent_step_mean(:,1),4);
%A = click_percent_step_mean(:,1);