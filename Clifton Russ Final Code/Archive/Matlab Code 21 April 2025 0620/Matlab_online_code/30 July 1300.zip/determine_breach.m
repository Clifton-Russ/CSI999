%This function determines whether an incident is a breach by comparing the
%incident ratio with the predefined success threshold. If the count exceeds
%the threshold, then a breach has occurred. This means that for any given
%number of controls, the person was able to circumvent that many controls.
%The more controls the person is able to circumvent, the more likely the
%person will have a breach
function [a_breach] = determine_breach(incidents,incident_intrusion)

% the incident threshold is a percent. Creates a forloop where threshold is
% compared to random number
incident_size = size(incidents,2);
a_breach = zeros(1,incident_size);
%a_breach = cell(1,1);

%a_breach = zeros(1,incident_size);
temp_total = zeros(1,incident_size);

for i = 1:incident_size % each element
    for j = 1: incidents(1,i) %total amount of incidents per typefor k = 1: threshold_size % total amount thresholds(vuln size)
        temp = rand(1,1);
        temp_total(1,i) = temp; 
        if temp < incident_intrusion %percent of a breach incident_threshold(1,i)
            a_breach(1,i) = 1; % this needs to be changed to be a cell
                %a_breach{1,1}(1,i)
        else
            a_breach(1,i) = 0;
        end
    end
    
end


end