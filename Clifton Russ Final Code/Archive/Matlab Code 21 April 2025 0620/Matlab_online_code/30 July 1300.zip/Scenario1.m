%% Scenario 1a Activity 1 input: 
% This section demonstrates multiple observations of activity

a_size_total = 10;% Number of agents
days = 50; % Number of days
actions_size = 4; % Number of actions (steps)

agent_compliance_average = [.60, .65, .70, .75, .80, .85, .90, .95];
agent_compliance_size = size(agent_compliance_average,2);
observation_size = 20;

click_percent_step_mean = cell(observation_size, agent_compliance_size);
report_rate = cell (observation_size,agent_compliance_size);


%% Multilple iterations of all the click rates
% This section creates multiple observations of all of the activities
for i = 1:observation_size
    for j = 1:agent_compliance_size
        [click_percent_step_mean{i,j},report_rate{i,j}, vuln_incident_total] = ...
            create_suborganization(a_size_total, days, agent_compliance_average(1,j), incident_threshold, phish_report_rate);
    end
end

%% Reorganization of observations

% This section reorganizes the data to create a cell data structure, where
% each entry represents click rates for each agent compliance score

agent_click = cell(1,agent_compliance_size);
temp2 = [];
for i = 1:observation_size
    for j = 1:agent_compliance_size
        temp = cell2mat(click_percent_step_mean(i,j));
        temp2 = [temp2;temp];     
    end
    agent_click{1,i} = temp2;
    temp2 = [];
end
%}
%% Activity1 click rates
% This section separates all the activity 1 click rates 
activity_1 =zeros(agent_compliance_size,observation_size);
for i = 1:observation_size
    activity_1(:,i) = agent_click{1,i}(:,1);
end
%% Graph Activity_1 points
click_size = size(agent_click,2);
agent_comp = [60 65, 70, 75, 80, 85, 90, 95];

for i = 1: click_size
    plot(agent_comp',activity_1(:,i));
    hold on
end
title("Agent Click Rate  (Checking Email)")
xlabel('Agent Compliance')
ylabel('Click Rate Percentage')
set(gcf, 'Name', 'By the Agent click Rate')
hold off
