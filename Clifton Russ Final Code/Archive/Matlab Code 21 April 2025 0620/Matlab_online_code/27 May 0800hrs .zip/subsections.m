%% Definitions
%checked_email = cell(click_size, org_size);
%report_email = cell(click_size,org_size);
%agent_email_total = cell(1,org_size);

%% Subsections at specific agent compliance level
checked_email = cell(1, org_size);
report_email = cell(1,org_size);
%agent_email = cell(click_size,days);
agent_email_total = cell(1,org_size);
%% Subsection 1 70%  125 people 
c_email = cell(a_size_total(1,1), days);
r_email = cell(a_size_total(1,1),days);
%agent_email = cell(click_size,days);
a_email_total = cell(a_size_total(1,1),days);


for m = 1: a_size_total(1,1)
    for n = 1: days
        [agent_email,~] = agent_interaction_create_email();
        a_email_total{m,n} = agent_email;
        [c_email{m,n}, r_email{m,n}] = calculate_email_report(v_total{3,1}{m,n},agent_email, actions_size);
    end
end

checked_email{1,1} = c_email;
report_email{1,1} = r_email;
agent_email_total{1,1} = a_email_total;

%% Subsection 2 75%  75 people 
c_email = cell(a_size_total(1,2), days);
r_email = cell(a_size_total(1,2),days);
%agent_email = cell(click_size,days);
a_email_total = cell(a_size_total(1,2),days);
%{

for m = 1: a_size_total(1,2)
    for n = 1: days
        [agent_email,~] = agent_interaction_create_email();
        a_email_total{m,n} = agent_email;
        [c_email{m,n}, r_email{m,n}] = calculate_email_report(v_total{4,1}{m,n},agent_email, actions_size);
    end
end

checked_email{1,2} = c_email;
report_email{1,2} = r_email;
agent_email_total{1,2} = a_email_total;
%}