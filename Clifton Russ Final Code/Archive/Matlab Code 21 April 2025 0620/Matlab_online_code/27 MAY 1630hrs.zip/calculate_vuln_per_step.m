function [vuln_per_step] = calculate_vuln_per_step(vuln_combo, vuln_control, vuln_idx)
% This function calculates the total vulnerabilities from each of the
% controls identified by the vuln combo. The vuln combo outlines which
% control families are aligned with each step. The vuln control represents
% all of the controls for each step. 

%This determines the number of control families and creates a storage for
%them to be merged
%temp_size = size(vuln_combo{1,vuln_idx}(1,:),2);
%temp_cell = cell(1,vuln_size);
%temp = cell(1,combo_size);
%vuln_merge = [];

%vuln_merge = cell(1,temp_size);
%actions_size = size(vuln_combo,1);
%num_control = size(vuln_control,1);
% this places all the controls into one cell array.

%{
for i = 1: temp_size
    temp = cell2mat(vuln_control(vuln_combo{1,vuln_idx}(1,i)));
    vuln_merge{1,i} = [cell2mat(vuln_merge(1,i)) temp]; 
end
%}
vuln_combo = cell2mat(vuln_combo);
combo_size = size(vuln_combo,2);
vuln_per_step = [];

for i = 1:combo_size
    temp = vuln_control(vuln_combo(1,i),vuln_idx);
    vuln_per_step = [vuln_per_step; temp];
    %vuln_control(vuln_combo{1,1}(1,:),:);
end


 %Change vuln merge to one merged cell   
 %vuln_merge2 = [];
 %temp3 = cell(actions_size,1);
    %for i = 1: temp_size
        %for j = 1: temp_size
            %temp2 = cell2mat(vuln_merge(1,j));
            %vuln_merge2{1,j} = cell2mat([vuln_merge2(1,j) temp2]);
       % end
    %end

end