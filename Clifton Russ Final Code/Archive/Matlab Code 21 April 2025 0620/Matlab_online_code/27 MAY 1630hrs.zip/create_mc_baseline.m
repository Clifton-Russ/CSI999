function [mc_baseline] = create_mc_baseline(actions_baseline)
mc = dtmc(actions_baseline); %creates markov chain from the actions baseline

%% Label State names
mc.StateNames = ["Emailing" "Web Browsing" "Text Messaging" "Phone Calling"];
%% Conduct simulation
mc_sum = sum(actions_baseline,2);% Calculates the total steps 
mc_steps = round(mean(mc_sum,1)); % determines the average steps a day

mc_baseline = simulate(mc, mc_steps);%simulates the steps for each day


%%
%{
% This creates a cell array of the baseline attributes for the agents. This
% will then be used to calculate each day.
%mc_baseline = cell(steps,1); 
mc_baseline = cell(1,steps);
actions_size = size(actions,2);
% For each iteration, the minimum values are reset and a new baseline of
% attributes are created for each person.
for i = 1:steps
    %min_max = zeros (2,5);

    %actions = create_mc_daily(mc_baseline,actions_size);
    %action_counter = determine_state_num(actions,min_max);
    actions = determine_state_num(actions,min_max);
    %mc_baseline{i,1} = action_counter; 
    mc_baseline{1,i} = actions;
end
%}
end