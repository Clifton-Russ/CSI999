%%
% Develop 250 personnel organization.
% Section 1: 100 personnel
    % agent average 70%
    % click rate: 2.5%
    % forward rate: 1%
    % report rate: 70%

% Section 2: 75 Personnel
    % agent average 65%
    % click rate: 3.5%
    % forward rate: 3.0%
    % report rate: 60%
    
% Section 3: 50 peresonnel
    % agent average 75%
    % click rate: 2.0%
    % forward rate: 1.0%
    % report rate: 75%

% Section 4: 25 personnel
    % agent average 80%
    % click rate: 1.0%
    % forward rate: 0.5%
    % report rate: 80%
%% Definitions

actions_size = 4;
a_size = 10;
days = 50;
agent_compliance_average = [.6,.65,.7, .75, .8, .85, .9, .95];

attribute_selection {1,1} = [.7467, .3624, .1073, .7538, .5053];
attribute_selection {2,1} = [0.9135,0.4975,0.0330,0.2703,0.6587,0.3627,0.3998];
attribute_selection {3,1} = [0.3830,0.2413,0.9665];
attribute_selection {4,1} = [0.2197,0.8792,0.3815];

%{
attribute_selection{1,1} = rand(1,5);
attribute_selection{2,1} = rand(1,7);
attribute_selection{3,1} = rand(1,6);
attribute_selection{4,1} = rand(1,5);
%}
incident_threshold = .043;


%% Create Suborgnization 
click_size = 8;
org_size = 4;

agent_click = cell(click_size,org_size);
total_report_rate = cell(click_size,org_size);
v_total = cell(click_size,org_size);
a_size_total = [2,4,6,4,2];

for i = 1: click_size
    for j = 1:org_size
        [click_percent_step_mean,report_rate, vuln_incident_total] = create_suborganization(a_size_total(1,j), days, agent_compliance_average(1,i), attribute_selection, incident_threshold);
        agent_click{i,j} = click_percent_step_mean;
        total_report_rate{i,j} = report_rate;
        v_total{i,j} = vuln_incident_total;
    end
end





%% Subsections at specific agent compliance level
checked_email = cell(1, org_size);
report_email = cell(1,org_size);
%agent_email = cell(click_size,days);
agent_email_total = cell(1,org_size);
%% Subsection 1 70%  100 people 
c_email = cell(a_size_total(1,1), days);
r_email = cell(a_size_total(1,1),days);
%agent_email = cell(click_size,days);
a_email_total = cell(a_size_total(1,1),days);


for m = 1: a_size_total(1,1)
    for n = 1: days
        [agent_email,~] = agent_interaction_create_email();
        a_email_total{m,n} = agent_email;
        [c_email{m,n}, r_email{m,n}] = calculate_email_report(v_total{3,1}{m,n},agent_email, actions_size);
    end
end

checked_email{1,1} = c_email;
report_email{1,1} = r_email;
agent_email_total{1,1} = a_email_total;

%% Subsection 2 60%  75 people 
c_email = cell(a_size_total(1,2), days);
r_email = cell(a_size_total(1,2),days);
%agent_email = cell(click_size,days);
a_email_total = cell(a_size_total(1,2),days);


for m = 1: a_size_total(1,2)
    for n = 1: days
        [agent_email,~] = agent_interaction_create_email();
        a_email_total{m,n} = agent_email;
        [c_email{m,n}, r_email{m,n}] = calculate_email_report(v_total{1,2}{m,n},agent_email, actions_size);
    end
end

checked_email{1,2} = c_email;
report_email{1,2} = r_email;
agent_email_total{1,2} = a_email_total;
%% Subsection 3 75%  50 people 
c_email = cell(a_size_total(1,3), days);
r_email = cell(a_size_total(1,3),days);
%agent_email = cell(click_size,days);
a_email_total = cell(a_size_total(1,3),days);


for m = 1: a_size_total(1,3)
    for n = 1: days
        [agent_email,~] = agent_interaction_create_email();
        a_email_total{m,n} = agent_email;
        [c_email{m,n}, r_email{m,n}] = calculate_email_report(v_total{4,3}{m,n},agent_email, actions_size);
    end
end
checked_email{1,3} = c_email;
report_email{1,3} = r_email;
agent_email_total{1,3} = a_email_total;

%% Subsection 4 80%  25 people 
c_email = cell(a_size_total(1,4), days);
r_email = cell(a_size_total(1,4),days);
%agent_email = cell(click_size,days);
a_email_total = cell(a_size_total(1,4),days);


for m = 1: a_size_total(1,4)
    for n = 1: days
        [agent_email,~] = agent_interaction_create_email();
        a_email_total{m,n} = agent_email;
        [c_email{m,n}, r_email{m,n}] = calculate_email_report(v_total{5,4}{m,n},agent_email, actions_size);
    end
end
checked_email{1,4} = c_email;
report_email{1,4} = r_email;
agent_email_total{1,4} = a_email_total;
