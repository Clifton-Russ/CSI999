function [vuln_index] = determine_vuln_index(vuln_control, v_size,e_thresholds)
% This function takes in the controls related to each vulnerability and
% then determines the index of each control to be later used to track all
% changes to vulnerabilities.
vuln_index = zeros(1,v_size);
for i = 1:v_size
    vuln_index(1,i) = find(e_thresholds == vuln_control(1,i));
end