function [training_data] = create_training_data(e_thresholds2, a_size, vuln_size, num_control, days,state_index)

vuln_control_count2 = cell(1,days);
%This section summarizes all the controls for each vulnerability. Each row
%represents the controls associated with the vulnerability (column).

%%%%%% %This is only using the last column size and needs update %%%%%
%%%% change vuln_size

% This takes the nth column of each day to summarize all the related
% controls for a particular vulnerability

%{
for i = 1: days
    for j = 1: vuln_size
        vuln_control_count2{1,i} = [e_thresholds2{1,i}{:,j}];
    end
end
%}

vuln_control_count2 = [];
%state_index = 1;
for i = 1: days
    for j = 1: vuln_size
        temp = e_thresholds2{1,i}(:,state_index);
        vuln_control_count2{1,i} = merge_col(num_control, temp) ; 
    end
end

%%
v_size = size(vuln_control_count2{1,state_index},2);
v_input = zeros(days,v_size);

%This 
for i = 1:days
    v_input(i,:) = cell2mat(vuln_control_count2(1,i));
end
%% Duplicate vectors for each person
% This duplicates the array for each person for each day
%{
training_data = [];
for i = 1:days
    temp = repmat(v_input(i,:),a_size,1);
    training_data = [training_data; temp];
end
%}
end