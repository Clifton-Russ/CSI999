function [e_temp] = create_new_env_score(e_thresholds, control_size)
e_temp = zeros(1,control_size(1,1)); % environment thresholds
for i = 1: control_size(1,1)   
        min = e_thresholds{1,1}(1,i)-(.05*e_thresholds{1,1}(1,i));
        max = e_thresholds{1,1}(1,i)+(.05*e_thresholds{1,1}(1,i));
        e_temp(1,i) = min + (max-min).*rand(1,1);
end   
end