function [vuln_total_control] = calculate_total_vuln(vuln_merge,actions_size, num_control, vuln_per_state)
% This takes the merged vulnerabilities and create final single 
    % arrays of entry

    % This is only doing one column and need to finish the remaining
    % columns
%{
    for i = 1: actions_size
        for j = 1: num_control
            temp = cell2mat(vuln_total_control(i,1));
            vuln_total_control{i,1} = [temp ,cell2mat(vuln_merge{i,1}(j,1))];
        end
    end
%}
  
    %input one step at a time vuln_merge(1,1)
    for i = 1: num_control
        temp = cell2mat(vuln_total_control(i,1));
        vuln_total_control{i,1} = [temp ,cell2mat(vuln_merge{i,1}(i,1))];
            %for k = 1: vuln_per_state(1,i)
            %    temp = cell2mat(vuln_total_control(i,k));
            %    vuln_total_control{i,k} = [temp ,cell2mat(vuln_merge{i,1}(j,k))];
            %end
    end
end