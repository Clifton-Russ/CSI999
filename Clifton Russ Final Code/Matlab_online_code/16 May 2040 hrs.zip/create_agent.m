%%
% This function creates an agent with the corresponding attributes. These
% agents are considered "reasonable" where some agents might follow all the
% rules while some might not. However, these agents do not include
% malicious actors
%%
function [people] = create_agent(start, stop,vuln_size)
%start is the number from where the forloop starts in the event there is a
%need to add additional agents without overwriting previous agents' ID
% num is the number of additional agents created
people = cell(stop,3);
xmin=.6;
xmax=.95;

%xmin = .1; %noncompliant agents
%xmax=.25; %noncompliant agents

for i = start: stop

compliance_score = xmin + (xmax-xmin).*rand(1,1);

    people{i,1} = i; % assigns unique PID
    people{i,2} = compliance_score; %rand('double'); %assigns random compliance score
    people{i,3} = determine_agent_threat(people{i,2},vuln_size);
end

end