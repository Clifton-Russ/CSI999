function [environment_compliance_score] = determine_environment_compliance(RMF_Control_Status)

n = size(RMF_Control_Status,2);
environment_compliance_score = size(1,n);

%% 
% Defining variables for random equation. These variables are used to 
% determine the efficiency of compliant or noncompliant control.
compliance_min = .7;
compliance_max = 1;
noncompliance_min = 0;
noncompliance_max = .5;
%%
for i = 1:n
    
    % If the control is compliant, indicated by the value "1", it is given
    % a score between .7 to 1 to represent efficiency.
    if RMF_Control_Status(1,i) == 1
        environment_compliance_score(1,i) = compliance_min + (compliance_max-compliance_min).*rand(1,1);
    end

    % If the control is noncompliant, indicated by the value "-1", it is given
    % a score between 0 to 0.5 to represent efficiency.
    if RMF_Control_Status(1,i) == -1
       environment_compliance_score(1,i) = noncompliance_min + (noncompliance_max-noncompliance_min).*rand(1,1);
    end
 
    % if the control is nonapplicable, indicated by the value "0", it is
    % given a score of "0".
    if RMF_Control_Status(1,i) == 0
        environment_compliance_score(1,i) = 0;
    end
end

end