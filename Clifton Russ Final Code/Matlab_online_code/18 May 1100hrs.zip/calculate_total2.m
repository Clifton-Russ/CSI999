% This counts all the incidents that occured at each step
function [incident_count] = calculate_total2(incident,mc_baseline,action_size) %m,n
 % removed this from return value incident_sum  
    mc_size = size(mc_baseline,1);
    temp = 0;
    incident_count = zeros(1,action_size);

    for i = 1: mc_size
    
        if mc_baseline(i,1) == 1 
                %temp = sum(cell2mat(incident{i,1}(1,1)));
                temp = sum(incident{i,1});
                incident_count(1,1) = incident_count(1,1) + temp; 
        end
        
    
        if mc_baseline(i,1) == 2   
             %temp = sum(cell2mat(incident{i,2}(1,1)));
             temp = sum(incident{i,2});
             incident_count(1,2) = incident_count(1,2) + temp;
       end

        if mc_baseline(i,1) == 3   
             %temp = sum(cell2mat(incident{i,3}(1,1)));
             temp = sum(incident{i,3});
             incident_count(1,3) = incident_count(1,3) + temp;
       end
      
       if mc_baseline(i,1) == 4   
             %temp = sum(cell2mat(incident{i,4}(1,1)));
             temp = sum(incident{i,4});
             incident_count(1,4) = incident_count(1,4) + temp;
       end
    
      % if mc_baseline(i,1) == 5   
      %       temp = sum(cell2mat(incident{i,5}(1,1)));
             %temp = sum(incident{i,5});
     %        incident_count(1,5) = incident_count(1,5) + temp;
     %  end

    end % for i = 1:mc_size
        incident_sum = sum(incident_count);
    
end