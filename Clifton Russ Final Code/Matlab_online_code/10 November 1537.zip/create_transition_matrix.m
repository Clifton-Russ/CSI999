function [transition_matrix] = create_transition_matrix(actions_baseline,m,n)
transition_matrix = 0;
for j = 1:sum(actions_baseline,2)
     if j < sum(actions_baseline,2)
        if transition_data(j,1) == m && transition_data(j+1,1) == n
            transition_matrix(1,1) = transition_matrix(1,1) + 1;
        end
     end
end

end