% Breach 3 is for setting up prediction modeling

%This function determines whether an incident is a breach by comparing the
%incident ratio with the predefined success threshold. If the count exceeds
%the threshold, then a breach has occurred. This means that for any given
%number of controls, the person was able to circumvent that many controls.
%The more controls the person is able to circumvent, the more likely the
%person will have a breach
function [a_breach, temp] = determine_breach3(vuln_1,incident_threshold, steps, attribute_size,likelihood)
% the incident threshold is a percent. Creates a forloop where threshold is
% compared to random number
%incident_size = size(vuln1_scores,2);
actions_size = size(vuln_1(1,:),2); %4 for vuln_1{1,1}(1,:)

a_breach = cell(steps,actions_size);
%a_breach = cell(steps,attribute_size);
% The a_breach_label aligns the vuln1_score with each breach to assist
% creating the input for the training. These are the labels.
%a_breach_label = zeros(attribute_size,1);
% input, idx


%for m = 1:actions_size %4

temp = 0;

for n = 1: steps %100+
    if isempty(cell2mat(vuln_1(n,actions_size))) == false 
        %if cell2mat((vuln_1(n,actions_size))) ~= 0
            %for i = 1:attribute_size(m,1) % each element
                % 21% is calculated the 365 days divided by the number incidents
                % that year. 
                %The temp is used to determine the likelihood of the breach
                %occurring.
                a_breach{n,1} = temp +1;
                %{
                if vuln_1{n,m}(1,i) == 1
                    temp = rand(1,1);
             
                   
                     if temp < likelihood
                        %percent of a breach incident_threshold(1,i)
                        if temp < incident_threshold 
                            a_breach{n,m}(1,i) = 1;
                            
                        else
                            a_breach{n,m}(1,i) = 0;
                        end
                    end
                end
                %}
            %end
        %end
    end

 end
end