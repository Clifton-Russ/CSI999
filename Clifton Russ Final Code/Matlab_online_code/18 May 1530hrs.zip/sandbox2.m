%% Thoughts
% Use unsupervised learning to see if the outcome is the same or able to
% predict new incidents
% Compare different types of supervised learning techniques
% 14 days for input, for 1 year, 3 years, 6 years and 10 years. Change each
% 14 days by +/- 10%.
% e_thresholds times the number of times the occurrence in the mc.
% Count the number of times each step.

% For each row of controls (represented by control by each day), [input],
% the output is a single digit or string for each any breach. If there is
% more than one, either the threat with the most breaches or a combination.

% calculate a way to determine the average of incidents per state. If the
% average is above 50%, then it's considered an incident. This will be the
% input for that day for that state.

% Determine state vuln and determine incident
% vuln control size determines the amount controls for each vulnerability.
% For each step, the total number of controls need to be calculated. For
% example, step 1 involves vuln1 and vuln 2, so add vuln size 1 and vuln
% size 2. Once that is added, then for each person, that number needs to be
% multiplied for the number of times each step occurs. For example, if
% person 1 was in step 1 10 times, then the number would be 10 times (vuln
% size 1 + vuln size 2). Once that number is calculated (vuln_total), that
% will act as the denominator. Dividing the part / whole will give a
% percentage of incidents. This number can then be used to either determine
% the output layer or label.

% output layer, each vulnerability (1 or 0) and NA (1 or 0). List all
% controls as the input. This trains against all vulnerabilities at once.

% control size = number of each controls for each vulnerability
% vuln_control count: sum of control size columns. The total amount of
% controls for each vulnerability
% vuln incident total = total sum of incidents per person, per day, per
% step.
% sort through mc-baseline to determine the amount steps per day.


% Currently, the vuln1 input and attribute information are random and need to be separated from
% specifically chosen controls.

% Need to focus on simulating agent movement and less on predictions.

%%
% Copy and paste Training Input for the other vulnerabilities and change
% the Incident. Then train neural network to with a 7 unit vector.


%% Calculate incident per agent
% This calculates all the incidents per agent
%{
final_matrix = cell(a_size,1);
for i = 1: a_size
      final_matrix{i,1} = calculate_incident(people{i,2},days, i_scores);
end
%}
%%
for i = 1: a_size
    for j = 1: days
       % c_percent{i,j} = vuln_breach_total./vuln_incident_total
    end
end
%%
attribute_size = zeros(1,actions_size);
for i = 1: actions_size
   attribute_size(i,1) = size(attribute_selection{i,1},2);
end
%%
attribute_average = zeros(1,365);

for i = 1: 365
    attribute_average(1,i) = mean(cell2mat((e_thresholds_daily{1,i}(1,1))));
end
%%
%isempty(cell2mat(vuln1_scores{1,1}(3,1)))
%likelihood = round(vuln1_scores(1,i)*.21);
% Converts the incident matrix to an array and sum all incidents
        %temp = sum(cell2mat(vuln1_scores{i,j}));
        % likelihood for agent clicking the link.
        %likelihood = round(temp *.21);
        likelihood = .51;
%%
%input label includes the vuln1_scores for the day and the +1 is the label
%to determine if it were a breach.
%input_label = zeros(days,attribute_size +1);
vuln_breach2 = cell(a_size,days);
temp = cell(a_size,days);

% This is only done for setting up for prediction modeling.
for i = 1: a_size
    for j = 1:days  
        
        [vuln_breach2{i,j}, temp{i,j}] = determine_breach3(vuln_1{i,j}, incident_threshold, steps(i,j),attribute_size,likelihood);
    end
    %input_label = cell2mat(vuln_breach{1,1}(1,1))';
end
%%

% This is the plot information for click rates click_rate_data
 click_rate_scatter = [73, .1; 72, 1.5; 70, 2.8; 68, 4.1; 66, 5.5; 64, 6.7; 62, 7.9; 60, 9.1; 58,  10.4; 56, 11.4; 54, 12.2; 52, 13.3];

%%
%A = rand(10,2);
scatter_graph = scatter(click_rate_scatter(:,1), click_rate_scatter(:,2));

%scatter_graph = scatter(click_rate_data(:,1), click_rate_data(:,2));
title("Click Rate per Compliance ")
xlabel('Compliance')
ylabel('Click Rate')
set(gcf, 'Name', 'Click Rate per Compliance')

%%
%incident_threshold = .7;
%test{1,1} = determine_breach3(vuln_1{1,1}, incident_threshold, steps(1,1),attribute_size,likelihood);
%%
% links, forward email. Then calculate per person, per day, per activity
% Fix determine breach. incident size is incorrect


% calculate instances where phishing attacks fail
% Determine the amount of people in survey/percentage
% Assume that the agents receive the same attacks
% range of steps, risk (phishing)/different
% controls.
% Slide 31- Social Engineering
% Used 21% for exposure based on the number of incidents reported within a
% year.
% adjust scores for various scenarios and then check to see if percentage
% is closer to 4%
% compare what happens when reduce the number of steps

%%
%1. Select controls again determine_attribute
% Need to calculalte for each agent as opposed to one person
% 98% email 
%% Individual agents
%This is only comparing to the environment controls for  vulnerability 1
%% Target Phishing (Whaling}
% 19% success rate [ Phishing Repo]

% This determines the amount of email each agent receives
a_size = 10;
email_population = randi([20 120],a_size,1);
phish_population = randi([4,7],a_size,1);
% This creates the email
agent_email = cell(a_size,1);

for i = 1:a_size
    agent_email{i,1} = zeros(1,email_population(i));
end
%% Select the phishing email
phish_selected = cell(a_size,1);
for i = 1: a_size
    phish_selected{i,1} = randi([20 email_population(i,1)],1,phish_population(i,1));
end
%% Assignd the email as phishing

for i = 1:a_size
    for j = 1:phish_population(i,1)
        agent_email{i,1}(1,phish_selected{i,1}(1,j)) = 1;
    end
end
%% Have the agents identify and report phishing emails
% Only check if attribute{i,1}(1,1) or attribute{i,1}(1,2). This simulates
% the ability for an agent to identify and report a phishing email based on
% their knowledge set. Higher score increases the likelihood of the agent
% reporting the email.

% agent identify phishing email
% How to calculate which emails to check
% Remove phishing email to see any improvement
% Impact of training
%%
%[agent_email,phish_selected] = agent_interaction_create_email(a_size);
[agent_email,phish_selected] = agent_interaction_create_email(10);

%%
% Change agent_email{1,1}(1,i) == 1 to check for invidual {j,1}(1,i)
% reset email_index at the test_function level to restart each day
% check for all 
%%
[agent_email,phish_selected] = agent_interaction_create_email(a_size);
control_size = vuln_incident_total{1,1}(1,1);
%email_number = 5; %randi([1 5],1,1); % selects the number of emails
report_email = zeros(1,actions_size);
checked_email = zeros(1,actions_size);
%email_index = 1;

for i = 1: actions_size
    email_index = 1;
    for j = 1: vuln_incident_total{1,1}(1,i)
        email_number = randi([1 5],1,1); % selects the number of emails
            if email_index + email_number < size(agent_email{1,1}(1,:),2)
                for k = email_index: email_index +email_number
                    if agent_email{1,1}(1,k) == 1
                        checked_email(1,i) = checked_email(1,i) +1;
                        temp = rand(1,1);
                            if temp < .70 % 70% chance of reporting phishing
                                report_email(1,i) = report_email(1,i) +1;
                            end
                    end
                    %email_index = email_index +email_number;
                end
                email_index = email_index +email_number;
            end
    end
end
    
%%
checked_email = cell(a_size, days);
report_email = cell(a_size,days);

for i = 1: a_size
    for j = 1: days
        [agent_email{i,j},phish_selected{i,j}] = agent_interaction_create_email(a_size);
        [checked_email{i,j}, report_email{i,j}] = calculate_email_report(vuln_incident_total{i,j},agent_email{i,j}, actions_size);
    end
end