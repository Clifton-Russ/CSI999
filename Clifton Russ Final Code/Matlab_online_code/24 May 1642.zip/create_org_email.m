function [checked_email,report_email] = create_org_email(vuln_incident_total, actions_size)
checked_email = cell(a_size, days);
report_email = cell(a_size,days);
%agent_email = cell(a_size,days);
agent_email_total = cell(1,days);

for i = 1: a_size
    for j = 1: days
        [agent_email,phish_selected] = agent_interaction_create_email();
        agent_email_total{1,j} = agent_email;
        [checked_email{i,j}, report_email{i,j}] = calculate_email_report(vuln_incident_total{i,j},agent_email, actions_size);
    end
end
end