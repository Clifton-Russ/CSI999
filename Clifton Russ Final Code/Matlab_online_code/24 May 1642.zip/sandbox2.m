%% Thoughts
% Use unsupervised learning to see if the outcome is the same or able to
% predict new incidents
% Compare different types of supervised learning techniques
% 14 days for input, for 1 year, 3 years, 6 years and 10 years. Change each
% 14 days by +/- 10%.
% e_thresholds times the number of times the occurrence in the mc.
% Count the number of times each step.

% For each row of controls (represented by control by each day), [input],
% the output is a single digit or string for each any breach. If there is
% more than one, either the threat with the most breaches or a combination.

% calculate a way to determine the average of incidents per state. If the
% average is above 50%, then it's considered an incident. This will be the
% input for that day for that state.

% Determine state vuln and determine incident
% vuln control size determines the amount controls for each vulnerability.
% For each step, the total number of controls need to be calculated. For
% example, step 1 involves vuln1 and vuln 2, so add vuln size 1 and vuln
% size 2. Once that is added, then for each person, that number needs to be
% multiplied for the number of times each step occurs. For example, if
% person 1 was in step 1 10 times, then the number would be 10 times (vuln
% size 1 + vuln size 2). Once that number is calculated (vuln_total), that
% will act as the denominator. Dividing the part / whole will give a
% percentage of incidents. This number can then be used to either determine
% the output layer or label.

% output layer, each vulnerability (1 or 0) and NA (1 or 0). List all
% controls as the input. This trains against all vulnerabilities at once.

% control size = number of each controls for each vulnerability
% vuln_control count: sum of control size columns. The total amount of
% controls for each vulnerability
% vuln incident total = total sum of incidents per person, per day, per
% step.
% sort through mc-baseline to determine the amount steps per day.


% Currently, the vuln1 input and attribute information are random and need to be separated from
% specifically chosen controls.

% Need to focus on simulating agent movement and less on predictions.


%%
%isempty(cell2mat(vuln1_scores{1,1}(3,1)))
%likelihood = round(vuln1_scores(1,i)*.21);
% Converts the incident matrix to an array and sum all incidents
        %temp = sum(cell2mat(vuln1_scores{i,j}));
        % likelihood for agent clicking the link.
        %likelihood = round(temp *.21);
       % likelihood = .51;
%%
%input label includes the vuln1_scores for the day and the +1 is the label
%to determine if it were a breach.

%{
vuln_breach2 = cell(a_size,days);
temp = cell(a_size,days);

% This is only done for setting up for prediction modeling.
for i = 1: a_size
    for j = 1:days  
        
        [vuln_breach2{i,j}, temp{i,j}] = determine_breach3(vuln_1{i,j}, incident_threshold, steps(i,j),attribute_size,likelihood);
    end
    %input_label = cell2mat(vuln_breach{1,1}(1,1))';
end
%}
%%
% links, forward email. Then calculate per person, per day, per activity
% Fix determine breach. incident size is incorrect


% calculate instances where phishing attacks fail
% Determine the amount of people in survey/percentage
% Assume that the agents receive the same attacks
% range of steps, risk (phishing)/different
% controls.
% Slide 31- Social Engineering
% Used 21% for exposure based on the number of incidents reported within a
% year.
% adjust scores for various scenarios and then check to see if percentage
% is closer to 4%
% compare what happens when reduce the number of steps

%%
%1. Select controls again determine_attribute
% Need to calculalte for each agent as opposed to one person
% 98% email 
%%
% Develop 250 personnel organization.
% Section 1: 100 personnel
    % agent average 70%
    % click rate: 2.5%
    % forward rate: 1%
    % report rate: 70%

% Section 2: 75 Personnel
    % agent average 65%
    % click rate: 3.5%
    % forward rate: 3.0%
    % report rate: 60%
    
% Section 3: 50 peresonnel
    % agent average 75%
    % click rate: 2.0%
    % forward rate: 1.0%
    % report rate: 75%

% Section 4: 25 personnel
    % agent average 80%
    % click rate: 1.0%
    % forward rate: 0.5%
    % report rate: 80%
%%
start = 1;
stop = 10;
actions_size = 4;
a_size = 10;
days = 365;
agent_compliance_average = [.6,.65,.7, .75, .8, .85, .9, .95];

attribute_selection {1,1} = [.7467, .3624, .1073, .7538, .5053];
attribute_selection {2,1} = [0.9135,0.4975,0.0330,0.2703,0.6587,0.3627,0.3998];
attribute_selection {3,1} = [0.3830,0.2413,0.9665];
attribute_selection {4,1} = [0.2197,0.8792,0.3815];

%{
attribute_selection{1,1} = rand(1,5);
attribute_selection{2,1} = rand(1,7);
attribute_selection{3,1} = rand(1,6);
attribute_selection{4,1} = rand(1,5);
%}
incident_threshold = .043;

%%
agent_comp = [60 65, 70, 75, 80, 85, 90, 95];
%% Create Suborganizations 
%Creates a loop where a suborganization is created and compairsons are made
%for each compliance level between 60 to 95 with increments of five. 
click_size = 8;
org_size = 5;

agent_click = cell(click_size,1);
total_report_rate = cell(click_size,1);
v_total = cell(click_size,1);

for i = 1: click_size
    for j = 1:org_size
        [click_percent_step_mean,report_rate, vuln_incident_total] = create_suborganization(start,stop, agent_compliance_average(1,i), attribute_selection, incident_threshold);
        agent_click{i,j} = click_percent_step_mean;
        total_report_rate{i,j} = report_rate;
        v_total{i,j} = vuln_incident_total;
    end
end
%{
for i = 1: click_size
    [click_percent_step_mean,report_rate, vuln_incident_total] = create_suborganization(start,stop, agent_compliance_average(1,i), attribute_selection, incident_threshold);
    agent_click{i,:} = click_percent_step_mean;
    total_report_rate{i,:} = report_rate;
    v_total{i,:} = vuln_incident_total;
end
%}
%%
%agent_click = toArray(agent_click,click_size);
%% This saves the plot in a temporary variable. The variable needs to be saved in order to be maintained. 
%click_figure = create_plot(agent_comp,agent_click, actions_size);
%%
% For each reported email, tag the email as reported. If an email is tagged
% as reported in the future, then it is considered "null".
%% This step separates the report rate from create_suborganization

%{
checked_email = cell(click_size, days);
report_email = cell(click_size,days);
agent_email = cell(click_size,days);
%agent_email_total = cell(1,days);


for i = 1: click_size
    for j = 1:org_size
        [checked_email{i,j},report_email{i,j}] = create_org_email(v_total{i,j}, actions_size);
    end
end

%}