function [extracted_cell] = extract_cell(vuln_1,index)
% This function extras a column of cells.

%This calculates the number of rows
cell_size = size(vuln_1{1,1},1);
extracted_cell = cell(cell_size,1);
temp_index = 1;

for i = 1:cell_size
    if ~isequal(vuln_1{1,1}{i,index}(1,1),0)
        extracted_cell{temp_index,1} = vuln_1{1,1}{i,index}(1,1);
        temp_index = temp_index +1;
    end
end
end