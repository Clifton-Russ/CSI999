function [final_vector] = merge_col(num_control,column)
% This function takes a column of cell entries, converts each cell into a
% matrix and then merges all entries into a single column. Within this
% project, this function is used take all of the controls related to a
% certain vulnerability.
final_vector = []; 
for i = 1: num_control
    temp2 = cell2mat(column(i,1));
    final_vector = [ final_vector temp2];
end
end