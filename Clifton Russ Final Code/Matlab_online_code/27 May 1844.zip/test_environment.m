
%% This class tests the environment controls

% Access Controls
AC_Controls = rand(520,30);

% Annual Training Controls
AT_Controls = rand(520,30);

% Auditing Controls
AU_Controls = rand(520,25);

% Configuration Management controls
CM_Controls = rand(520,21);

% Physical Controls
PE_Controls = rand(520,27);

% Risk Assessment Controls
RA_Controls = rand(520,25);
%%
% This ranks the features
[AC_Controls_idx, AC_Controls_score] = fsulaplacian(AC_Controls);
AC_Controls_size = size(AC_Controls,2);
AC_Controls_rank = zeros(1,AC_Controls_size);
for i = 1: AC_Controls_size
    AC_Controls_rank(AC_Controls_idx(i))= i;
end

feature_Rg_150 = [AC_Controls_rank',AC_Controls_score(AC_Controls_idx)'];

%% Graphing Radius 150

bar(AC_Controls_score(AC_Controls_idx));
xlabel('Feature rank')
ylabel('Feature importance score')
set(gcf, 'Name','AC Controls Ranked Features');
%% Vulnerability average scores

AC_compliance = mean(AC_Controls);

AT_compliance = mean(AT_Controls);

AU_compliance = mean(AU_Controls);

CM_compliance = mean(CM_Controls);

PE_compliance = mean(PE_Controls);

RA_compliance = mean(RA_Controls);

num_control = 6;
%% Merge Environment
%{
control_compliance = [AC_compliance, AT_compliance, AU_compliance ...
    CM_compliance, PE_compliance, RA_compliance];
%}
control_compliance = [AC_Controls, AT_Controls, AU_Controls, CM_Controls, ...
    PE_Controls, RA_Controls];
%% Biweekly changes to control compliance for a period of time.
%{
control_change = zeros(1,vuln_size);
iterations = 100;
for i = 1: iterations
        for j = 1:vuln_size   
            min = control_compliance(1,j)-(.1*control_compliance(1,j));
            max = control_compliance(1,j)+(.1*control_compliance(1,j));
            control_change(i,j) = min + (max-min).*rand(1,1);
        end
end
%}
%% Alternative Method
% Instead of taking the average, just merge all the scores into one vector.
% If a control is not applicable, then give it a zero.
% For label values, use a cell