function [actions_baseline] = create_action_baseline(actions_initial)
%This function takes the initial actions vector and creates additional
%vectors to create an nxn matrix to be later used for the Markov Chain

initial_size = size(actions_initial,2);

actions_baseline = zeros(initial_size,initial_size);

for i = 1: initial_size
    for j = 1:initial_size   
         min = actions_initial(1,j)-(.1*actions_initial(1,j));
         max = actions_initial(1,j)+(.1*actions_initial(1,j));
         actions_baseline(i,j) = round(min + (max-min).*rand(1,1));
            
    end
end


%% Normalize the data
% This section normalizes the data to be a percentage of 100%.

%Determine the sum of each row
temp = sum(actions_baseline,2);
temp = actions_baseline./temp;
actions_baseline = round(temp*100);
end