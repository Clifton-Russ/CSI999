function [click_figure] = create_plot(agent_comp,agent_click, actions_size)
%% Scatterplot of percentages

%click_size = size(agent_click,2);

for i = 1: actions_size
    scatter(agent_comp',agent_click(:,i));
    hold on
end
title("Agent Click Rate  (" + actions_size + " steps)")
xlabel('Agent Compliance')
ylabel('Click Rate Percentage')
set(gcf, 'Name', 'By the Agent click Rate')
legend('Messenger','Web-Surfing','Mobile Phone','Checking Email')
click_figure = figure;
hold off

end