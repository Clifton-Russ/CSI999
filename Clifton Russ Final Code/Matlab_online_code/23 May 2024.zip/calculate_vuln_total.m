function [vuln_total_control] = calculate_vuln_total(vuln_merge,num_control,vuln_size,vuln_combo)
    %counter = size(vuln_merge,2);
    counter = size(vuln_merge,1);
    control_family = size(vuln_merge,1);
    %counter = size(cell2mat(vuln_merge{1,1}),2);
    vuln_total_control =cell(1,counter); %[];
    temp = cell(1,counter);
    
    %counter = size(cell2mat(vuln_merge(1,1)),2);
    %vuln_total_control =cell(1,vuln_size); %[];
    %temp = cell(1,vuln_size);

    % Take the size of the vuln_merge that is being passed. This will vary
    % and might have more than one row depending on the associated control
    % families. Change the forloop to take in consideration the size of the
    % vuln_merge 

    % for i = 1: num_control
        %temp = cell2mat(vuln_total_control(1,i));
    % temp = cell2mat(vuln_total_control(1,1));
     
        %vuln_total_control{1,vuln_combo{1,1}(1,i)} = [temp ,cell2mat(vuln_merge(j,i))];
        %vuln_total_control{1,i} = [temp ,cell2mat(vuln_merge(j,i))];
     % vuln_total_control{1,1} = [temp, cell2mat(vuln_merge(i,1))];
    %end


  for i = 1: counter %control_family  
        for j = 1: control_family %counter
            %temp = cell2mat(vuln_total_control(1,i));
            temp = cell2mat(vuln_total_control(1,1));
            %vuln_total_control{1,vuln_combo{1,1}(1,i)} = [temp ,cell2mat(vuln_merge(j,i))];
            %vuln_total_control{1,i} = [temp ,cell2mat(vuln_merge(j,i))];
            %vuln_total_control{1,1} = [temp, cell2mat(vuln_merge(j,i))];
             vuln_total_control{1,j} = [temp, cell2mat(vuln_merge(j,i))];
        end
   end

   %{ 
    for i = 1: control_family  
        for j = 1: counter
            %temp = cell2mat(vuln_total_control(1,i));
            temp = cell2mat(vuln_total_control(1,1));
            %vuln_total_control{1,vuln_combo{1,1}(1,i)} = [temp ,cell2mat(vuln_merge(j,i))];
            %vuln_total_control{1,i} = [temp ,cell2mat(vuln_merge(j,i))];
            vuln_total_control{1,1} = [temp, cell2mat(vuln_merge(i,j))];
        end
    end
    %}
end