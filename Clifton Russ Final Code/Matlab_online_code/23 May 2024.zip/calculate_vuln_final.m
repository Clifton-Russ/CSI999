function [vuln_matrix] = calculate_vuln_final(vuln_per_step)
% This method creates the final list of controls to use by combining all
% the controls for each vulnerability.



%vuln_size = size(vuln_per_step,2);

%vuln_matrix = cell(actions_size,1);
vuln_matrix = cell(1,1);
%for i = 1: actions_size
    %num_control = size(vuln_per_step{i,1},1);
    %num_control = size(vuln_per_step{1,1},1);
    num_control = size(vuln_per_step,1);

    for i = 1:num_control
        vuln_matrix{1,1} = [cell2mat(vuln_matrix(1,1)) vuln_per_step{i,1}];
        %vuln_matrix{1,1} = cell2mat([vuln_matrix{1,1} vuln_per_step{1,1}{1,1}]);
        %vuln_matrix{i,1} = cell2mat([vuln_matrix(i,1) vuln_per_step{i,1}{j,1}]);
    end
%end

%{
for i = 1: num_control
    for j = 1: vuln_size
        vuln_matrix{1,j} = cell2mat([vuln_matrix(1,j) vuln_per_step(i,j)]);
    end
 end
%}

end