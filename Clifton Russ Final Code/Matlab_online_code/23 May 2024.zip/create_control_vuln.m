function [ctrl_temp] = create_control_vuln(attribute_selection, control_size)

%ctrl_temp = zeros(1,control_size(1,1)); % environment thresholds
ctrl_temp = zeros(1,control_size); % environment thresholds
for i = 1: control_size%(1,1)   
        min = attribute_selection{1,1}(1,i)-(.15*attribute_selection{1,1}(1,i));
        max = attribute_selection{1,1}(1,i)+(.15*attribute_selection{1,1}(1,i));
        ctrl_temp(1,i) = min + (max-min).*rand(1,1);
end


%{
ctrl_temp = zeros(1,control_size(1,1)); % environment thresholds
for i = 1: control_size(1,1)   
        min = e_thresholds{1,1}(1,i)-(.15*e_thresholds{1,1}(1,i));
        max = e_thresholds{1,1}(1,i)+(.15*e_thresholds{1,1}(1,i));
        ctrl_temp(1,i) = min + (max-min).*rand(1,1);
end   
%}

%{
i_size = size(attribute_selection,2);
i_scores = zeros(days,i_size);

for P = 1: days 
    for Q = 1: i_size
        min = attribute_selection(1,Q)-(.15*attribute_selection(1,Q));
        max = attribute_selection(1,Q)+(.15*attribute_selection(1,Q));
        i_scores(P,Q)= min + (max-min)*rand(1,1);
    end
end
%}
end